# strcode 0.2.0

## Major Changes

* code separators can now be inserted via shiny
* code separators can now contain code anchors to uniquely identify a 
  code section
* code anchors can also be inserted as stand alones 
* code sections that are inserted with shiny and and have titles are
  regocnized as code sections by RStudio
* code files can now be summarized with a function `sum_str`

