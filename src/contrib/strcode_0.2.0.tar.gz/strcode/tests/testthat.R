library("testthat")
test_check("strcode")
