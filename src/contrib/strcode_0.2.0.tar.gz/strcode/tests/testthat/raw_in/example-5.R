# this should give all 3 levels of granularity and titles for all sectios
#   ____________________________________________________________________________
#   header                                                                  ####
a <- function(x) {
  # a comment
  #### a comment2
}

##  ............................................................................
##  section 2                                                               ####
###   not to show

##  ............................................................................
##  Another section 2                                                       ####

### . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ..
### full 3                                                                  ####
g <- function(k) {
  a <- 3
}

### . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ..
### a long section title ajfasklf af ddisdf sfad faskljf dflasdjf ras fslkd ####
